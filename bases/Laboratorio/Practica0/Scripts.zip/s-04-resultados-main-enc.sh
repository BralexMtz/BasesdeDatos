tr 'A-Za-z' 'N-ZA-Mn-za-m' <<EOF | bash -
  #!/ova/onfu
  ge '!-~' 'C-~!-B' < f-04-erfhygnqbf-rap.fu | onfu -
EOF
